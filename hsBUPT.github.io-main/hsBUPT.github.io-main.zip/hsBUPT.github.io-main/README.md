# [hsBUPT.github.io]()

-----------------------------------------------------------------------------------------------

## This project is adapted from GitHub imsyy's home. You can fork it to your own repository and name it `username.github.io`, then run it!

### update log

#### Ver 1.1

**Search boxes and styles have been added to the original author, ~~and click events and search engines will be added later.~~** **Join the search engine and optimize the search experience.Join the search engine and optimize the search experience.**

![search-btn](https://img1.imgtp.com/2023/06/03/7iz95ogk.png)

![search-line](https://img1.imgtp.com/2023/06/03/bG5fqM9L.png)

### Tips

**After I add the search engine, You can set this Demo as the browser home page through the edge Settings.**

![](https://img1.imgtp.com/2023/06/03/GSytnrP1.png)
